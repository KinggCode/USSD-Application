<?php

	$_SESSION['sess'] = 0 ;

?>